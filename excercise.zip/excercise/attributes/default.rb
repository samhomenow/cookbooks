default['servername']="node204"
default['pack']=['systemd','bash-completion']
default['user']='praveen'
