#
# Cookbook Name:: build_cookbook
# Recipe:: smoke
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
include_recipe 'delivery-truck::smoke'
