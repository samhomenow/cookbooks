name             'test-patrick'
maintainer       'Pearson Business English'
maintainer_email 'patrick.daly@pearson.com'
license          'All rights reserved'
description      'Installs/Configures test-patrick'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.8.0'